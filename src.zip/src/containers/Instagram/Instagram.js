import React, { Fragment } from 'react'

const Instagram =props=>{<Fragment>
      <div
          style={{
            height: "40px",
            width: "40px",
            position: "absolute",
            borderRadius: "100px",
            top: "10px",
          }}
        ></div>
        <div style={{ width: "70%", left: "50px" }}></div>
        <div style={{ width: "40%", left: "50px" }}></div>
        <div style={{ width: "40%", left: "50px" }}></div>
        <div style={{ width: "40%", left: "50px" }}></div>
        <div style={{ width: "40%", left: "50px" }}></div>
        <div style={{ width: "90%", left: "0", marginTop: "30px" }}></div>
        <div style={{ width: "90%", left: "0" }}></div>
</Fragment>}

export default Instagram;